//
// LineaPro-TiModule Demo
// Created 2012-07-24 by Paul Nelson
// Updated 2012-07-24 by Paul Nelson
//

var App 			= Ti.UI.createWindow(),
	RootWindow		= Ti.UI.createWindow({backgroundColor:'#FFF',title:'LineaPro-TiModule Demo'});
	RootTableView	= Ti.UI.createTableView(),
	Nav		 		= Ti.UI.iPhone.createNavigationGroup({window:RootWindow});
	
var data 	= [];
	data[0] = Ti.UI.createTableViewRow({title:'ConnectionState => CONN_DISCONNECTED',font:{fontSize:12}});
	data[1] = Ti.UI.createTableViewRow({title:'CurrentBarcode => ',font:{fontSize:12}});
	RootTableView.setData(data);
		
	RootWindow.add(RootTableView);
	
	App.add(Nav);
	
	App.open();
	
lineaprotimodule.getConnectionState();													// By default, load initial connectionState

// Require lineaprotimodule after application has loaded.	
var lineaprotimodule = require('lineaprotimodule');

data[0].addEventListener('click', function() {											// On tableViewRow click, Check connectionState
	this.title = 'ConnectionState => ' + lineaprotimodule.getConnectionState();
});


lineaprotimodule.getCurrentBarcode();

setInterval(function() {
	data[1].title = 'CurrentBarcode => ' + lineaprotimodule.getCurrentBarcode();
}, 1000);
